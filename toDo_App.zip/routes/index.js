const express = require('express');
const router =  express.Router();

const homeController = require('../controllers/home_controller');

console.log('router is loaded');

router.get('/', homeController.homePage);
// routes handle add and delete task 
router.post('/add-task', homeController.addTask);
router.post('/delete-task', homeController.deleteTask);


module.exports = router;