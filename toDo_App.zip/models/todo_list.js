const mongoose =  require('mongoose');

// const todoListSchema = mongoose.Schema();

const todoListSchema = new mongoose.Schema({
    description : {
        type:String,
        required:true
    },
    category:{
        type:String,
        required:true
    },
    dueDate: {
        type: Date,
        required:true
    }
}, {
    timestamps:true // Automatically add 'createdAt' and 'updatedAt' fields
});

const TodoList = mongoose.model('TodoList', todoListSchema);

module.exports = TodoList;